require 'origin.common'

local default_map = {}

--------------------------------------------------
-- Map Callbacks
--------------------------------------------------
function default_map.Init(map)
	DEBUG.EnableDbgCoro() --Enable debugging this coroutine
	PrintInfo("=>> Init_default_map")

	
	GAME:UnlockDungeon('example_dungeon_a')
	COMMON.RespawnAllies()
end

function default_map.Enter(map)
	DEBUG.EnableDbgCoro() --Enable debugging this coroutine
	
	SV.checkpoint = 
	{
		Zone = 'mystery_zone', Segment = -1,
		Map = 0, Entry = 0
	}
	GAME:FadeIn(20)
end

--------------------------------------------------
-- Objects Callbacks
--------------------------------------------------

function default_map.North_Exit_Touch(obj, activator)
	DEBUG.EnableDbgCoro() --Enable debugging this coroutine
	local dungeon_entrances = { 'example_dungeon_a', 'example_dungeon_b', 'example_dungeon_c' }
	local ground_entrances = {}
	COMMON.ShowDestinationMenu(dungeon_entrances,ground_entrances)
end

function default_map.Assembly_Action(obj, activator)
	DEBUG.EnableDbgCoro() --Enable debugging this coroutine
	UI:ResetSpeaker()
	COMMON.ShowTeamAssemblyMenu(obj, COMMON.RespawnAllies)
end

function default_map.Storage_Action(obj, activator)
	DEBUG.EnableDbgCoro() --Enable debugging this coroutine
	COMMON:ShowTeamStorageMenu()
end

function default_map.Teammate1_Action(chara, activator)
	DEBUG.EnableDbgCoro() --Enable debugging this coroutine
	COMMON.GroundInteract(activator, chara)
end

function default_map.Teammate2_Action(chara, activator)
	DEBUG.EnableDbgCoro() --Enable debugging this coroutine
	COMMON.GroundInteract(activator, chara)
end

function default_map.Teammate3_Action(chara, activator)
	DEBUG.EnableDbgCoro() --Enable debugging this coroutine
	COMMON.GroundInteract(activator, chara)
end

return default_map
